﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour {

    private Rigidbody2D rb2d_Player;
    private Transform transform_Player;
  
    public float speed;
    //public Transform bottomChecker;
    public Transform topChecker;
    public Transform playerFeet;
    public float defaultScale = 10;

    void Awake()
    {
        // Assigns components to variables
        rb2d_Player = GetComponent<Rigidbody2D>();
        transform_Player = GetComponent<Transform>();
    }

    private void Start()
    {
        
    }

    void Update()
    {
        
        // The y positions of the players feet and top of the screen
        float playerPos = playerFeet.position.y;
        float topPos = topChecker.position.y;

        // Sets the players scale depending on how close to the top the player is.
        transform_Player.localScale = new Vector2(playerPos/topPos * -10 + defaultScale, playerPos / topPos * -10 + defaultScale);


        
    }

    void FixedUpdate()
    {

        // Sets WASD/Arrow Keys as variables
        float moveHorizontal = Input.GetAxisRaw("Horizontal");
        float moveVertical = Input.GetAxisRaw("Vertical");

        // Makes a Vector for the Player Object to travel on
        Vector2 movement = new Vector2(moveHorizontal, moveVertical);
        
        // Moves the player on the Vector created by setting its Velocity
        rb2d_Player.velocity = movement * speed;

    }

}
